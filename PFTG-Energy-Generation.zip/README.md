# Field-Driven Energy Generation (PFTG-Based)

This repository contains the full paper and supporting figures for:

**Field-Driven Energy Generation via Local Pressure Gradients**  
_A Theoretical Framework under Pressure-Field Gravity_  
**Author:** Joey Harper  
**Year:** 2025

## 🔬 Abstract

This paper explores how localized scalar pressure gradients — as modeled in the Pressure-Field Theory of Gravity (PFTG) — may be harnessed to extract energy from vacuum tension or gravitational asymmetry, offering a potential framework for nontraditional energy systems.

## 📄 Paper

👉 [Read the Full Paper (PDF)](./Field_Driven_Energy_Generation.pdf)

## 📊 Figures

All supporting diagrams (Appendix B) are located in the `/figures` folder.

## 📚 Citation

```
Joey Harper. "Field-Driven Energy Generation via Local Pressure Gradients: A Theoretical Framework under Pressure-Field Gravity", 2025.
```

## 📬 Contact

📧 joeyharper1985@gmail.com  
🌐 https://joeyharper52.github.io
